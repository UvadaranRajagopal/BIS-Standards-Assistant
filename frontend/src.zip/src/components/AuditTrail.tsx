import { useEffect, useState } from "react";

import {
  ShieldCheck,
  AlertTriangle,
  Clock,
  FileCheck,
  FileText,
  UserCheck,
  CheckCircle,
} from "lucide-react";

import { auditApi } from "../services/api";


export default function AuditTrail() {

  const [logs, setLogs] = useState<any[]>([]);

  const [integrity, setIntegrity] =
    useState("checking");


  useEffect(() => {

    async function loadAudit() {

      try {

        const [
          logsData,
          integrityData,
        ] = await Promise.all([

          auditApi.getLogs(),

          auditApi.verifyIntegrity(),

        ]);


        setLogs(
          Array.isArray(logsData)
            ? logsData
            : logsData.logs || []
        );


        if (
          integrityData.valid === true ||
          integrityData.integrity === "valid"
        ) {

          setIntegrity("valid");

        } else {

          setIntegrity("invalid");

        }

      } catch (error) {

        console.error(
          "Audit loading failed:",
          error
        );

        setIntegrity("unavailable");

      }

    }


    loadAudit();

  }, []);


  // Backend stores timestamps in UTC without "Z".
  // Convert them correctly to IST for display.
  const formatIST = (timestamp: string) => {

    if (!timestamp) {
      return "";
    }

    const utcTimestamp = timestamp.endsWith("Z")
      ? timestamp
      : timestamp + "Z";

    return (
      new Date(utcTimestamp).toLocaleString("en-IN", {
        timeZone: "Asia/Kolkata",
        day: "2-digit",
        month: "short",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        hour12: true,
      }) + " IST"
    );

  };


  // Get tender ID from the audit event
  const getTenderId = (log: any) => {

    return (
      log.data?.tender_id ||
      log.tender_id ||
      "N/A"
    );

  };


  // Get accepted standards
  const getAcceptedStandards = (log: any) => {

    const standards =
      log.data?.accepted_standards;

    if (!standards) {
      return null;
    }

    if (Array.isArray(standards)) {
      return standards;
    }

    return [standards];

  };


  // Get certification verification details
  const getCertificationVerifications = (log: any) => {

    return (
      log.data?.certification_verifications ||
      null
    );

  };


  // Human-friendly action title
  const getActionTitle = (action: string) => {

    switch (action) {

      case "standards_analyzed":
        return "Standards Analyzed";

      case "standards_accepted":
        return "Officer Accepted Standards";

      case "pdf_generated":
        return "PDF Bundle Generated";

      default:
        return action || "System Action";

    }

  };


  // Choose icon based on action
  const getActionIcon = (action: string) => {

    switch (action) {

      case "standards_analyzed":
        return <FileCheck size={18} />;

      case "standards_accepted":
        return <UserCheck size={18} />;

      case "pdf_generated":
        return <FileText size={18} />;

      default:
        return <ShieldCheck size={18} />;

    }

  };


  return (

    <section className="audit-page-card">

      {/* HEADER */}

      <div className="audit-page-header">

        <div>

          <h3>Audit Integrity</h3>

          <p>
            Hash-chain verification of recorded procurement actions
          </p>

        </div>


        <div
          className={
            integrity === "valid"
              ? "integrity-valid"
              : "integrity-invalid"
          }
        >

          {integrity === "valid" ? (

            <>
              <ShieldCheck size={19} />
              Integrity Valid
            </>

          ) : (

            <>
              <AlertTriangle size={19} />
              {integrity}
            </>

          )}

        </div>

      </div>


      {/* AUDIT EVENTS */}

      <div className="audit-list">

        {logs.length === 0 ? (

          <div className="empty-audit">

            <Clock size={25} />

            <p>
              No audit events recorded yet.
            </p>

          </div>

        ) : (

          logs
            .slice()
            .reverse()
            .map((log, index) => {

              const standards =
                getAcceptedStandards(log);

              const certificationVerifications =
                getCertificationVerifications(log);

              return (

                <div
                  className="audit-event"
                  key={log.index ?? index}
                >

                  {/* ICON */}

                  <div className="audit-event-icon">

                    {getActionIcon(log.action)}

                  </div>


                  {/* MAIN CONTENT */}

                  <div className="audit-event-content">

                    <strong>
                      {getActionTitle(log.action)}
                    </strong>


                    <span>
                      Officer:{" "}
                      {log.user_id || "System"}
                    </span>


                    <span>
                      Tender:{" "}
                      {getTenderId(log)}
                    </span>


                    {/* ACCEPTED STANDARDS */}

                    {standards &&
                      standards.length > 0 && (

                        <div
                          style={{
                            marginTop: "6px",
                            fontSize: "13px",
                          }}
                        >

                          <strong>
                            Accepted Standards:
                          </strong>

                          <div>

                            {standards.map(
                              (
                                standard: string,
                                standardIndex: number
                              ) => (

                                <span
                                  key={standardIndex}
                                  style={{
                                    display: "inline-block",
                                    marginRight: "8px",
                                    marginTop: "4px",
                                    padding:
                                      "3px 8px",
                                    borderRadius:
                                      "6px",
                                    background:
                                      "#eef4ff",
                                    color:
                                      "#2457a6",
                                    fontSize:
                                      "12px",
                                  }}
                                >
                                  {standard}
                                </span>

                              )
                            )}

                          </div>

                        </div>

                      )}


                    {/* CERTIFICATION VERIFICATION */}

                    {certificationVerifications &&
                      Object.keys(
                        certificationVerifications
                      ).length > 0 && (

                        <div
                          style={{
                            marginTop: "10px",
                            padding: "10px 12px",
                            borderRadius: "8px",
                            background: "#f0fdf4",
                            border: "1px solid #bbf7d0",
                            fontSize: "13px",
                          }}
                        >

                          <div
                            style={{
                              display: "flex",
                              alignItems: "center",
                              gap: "6px",
                              marginBottom: "6px",
                              fontWeight: 600,
                              color: "#166534",
                            }}
                          >

                            <CheckCircle size={15} />

                            Certification Verification

                          </div>


                          <div
                            style={{
                              display: "flex",
                              flexDirection: "column",
                              gap: "4px",
                            }}
                          >

                            {Object.entries(
                              certificationVerifications
                            ).map(
                              (
                                [
                                  standard,
                                  verified,
                                ]
                              ) => (

                                <div
                                  key={standard}
                                  style={{
                                    display: "flex",
                                    alignItems: "center",
                                    gap: "6px",
                                    color:
                                      verified
                                        ? "#166534"
                                        : "#b91c1c",
                                  }}
                                >

                                  {verified ? (
                                    <CheckCircle
                                      size={14}
                                    />
                                  ) : (
                                    <AlertTriangle
                                      size={14}
                                    />
                                  )}

                                  <span>
                                    {standard}
                                  </span>

                                  <span
                                    style={{
                                      fontWeight: 600,
                                    }}
                                  >
                                    {verified
                                      ? "Verified"
                                      : "Not Verified"}
                                  </span>

                                </div>

                              )
                            )}

                          </div>

                        </div>

                      )}


                    {/* PDF PATH */}

                    {log.data?.pdf_generated && (

                      <span>
                        PDF:{" "}
                        {String(
                          log.data.pdf_generated
                        )
                          .split("\\")
                          .pop()
                          ?.split("/")
                          .pop()}
                      </span>

                    )}

                  </div>


                  {/* TIME */}

                  <small>
                    {formatIST(log.timestamp)}
                  </small>

                </div>

              );

            })

        )}

      </div>


      {/* FOOTER */}

      <div
        style={{
          marginTop: "18px",
          paddingTop: "14px",
          borderTop: "1px solid #e5e7eb",
          display: "flex",
          alignItems: "center",
          gap: "8px",
          fontSize: "12px",
          color: "#64748b",
        }}
      >

        <ShieldCheck size={15} />

        <span>
          All procurement actions are recorded in a
          tamper-evident SHA-256 hash chain.
        </span>

      </div>

    </section>

  );

}