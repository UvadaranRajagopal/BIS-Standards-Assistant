import { useState } from "react";

import FileUpload from "../components/FileUpload";
import RequirementCard from "../components/RequirementCard";

import { standardsApi, pdfApi } from "../services/api";

import {
  Search,
  Sparkles,
  AlertCircle,
} from "lucide-react";

import { useNavigate } from "react-router-dom";

export default function AnalyzeTender() {

  const navigate = useNavigate();

  const [file, setFile] = useState<File | null>(null);

  const [requirement, setRequirement] = useState("");

  const [loading, setLoading] = useState(false);

  const [error, setError] = useState("");


  const analyze = async () => {

    const query = requirement.trim();

    if (!file && !query) {
      setError(
        "Please upload a PDF or enter a procurement requirement."
      );
      return;
    }

    setLoading(true);
    setError("");

    try {

      let analysisQuery = query;

      /*
       * If a PDF was uploaded, extract its text first.
       */
      if (file) {

        const extracted = await pdfApi.extract(file);

        analysisQuery = extracted.text.trim();

        if (!analysisQuery) {
          throw new Error(
            "No usable text was found in the uploaded PDF."
          );
        }
      }

      /*
       * Send the extracted PDF text or
       * manually entered requirement to the
       * existing BIS RAG analysis pipeline.
       */
      const result = await standardsApi.analyze(
        analysisQuery,
        3
      );

      sessionStorage.setItem(
        "analysisResult",
        JSON.stringify(result)
      );

      navigate("/standards");

    } catch (err: any) {

      console.error(err);

      const detail = err.response?.data?.detail;

      setError(
        typeof detail === "string"
          ? detail
          : err.message ||
            "Unable to analyze the procurement requirement."
      );

    } finally {

      setLoading(false);

    }
  };


  return (
    <div>

      <div className="page-title">

        <div>

          <span className="header-label">
            NEW ANALYSIS
          </span>

          <h2>Analyze Procurement Requirement</h2>

          <p>
            Upload a tender document or enter the requirement
            manually to identify applicable BIS standards.
          </p>

        </div>

      </div>


      <div className="analysis-layout">

        <div className="analysis-main">

          <section className="panel">

            <div className="section-heading">

              <div className="section-icon">
                <Search size={20} />
              </div>

              <div>
                <h3>1. Provide Requirement</h3>
                <p>
                  Upload a PDF or enter the requirement below.
                </p>
              </div>

            </div>


            <FileUpload
              onFileSelect={(selectedFile) =>
                setFile(selectedFile)
              }
            />


            <div className="or-divider">
              <span>OR ENTER MANUALLY</span>
            </div>


            <textarea
              className="requirement-input"
              value={requirement}
              onChange={(e) =>
                setRequirement(e.target.value)
              }
              placeholder="Example: We need LED street lights for a highway project..."
              rows={7}
            />


            {file && (

              <div className="info-message">

                <AlertCircle size={18} />

                <span>
                  PDF selected: {file.name}.
                  The tender text will be extracted and
                  analyzed automatically.
                </span>

              </div>

            )}


            {error && (

              <div className="error-message">

                <AlertCircle size={18} />

                {error}

              </div>

            )}


            <button
              className="primary-button analyze-button"
              onClick={analyze}
              disabled={loading}
            >

              <Sparkles size={19} />

              {loading
                ? "Extracting PDF & analyzing..."
                : "Analyze Requirement"}

            </button>

          </section>


          <section className="info-panel">

            <h3>What happens after analysis?</h3>

            <div className="mini-steps">

              <span>01</span>
              Semantic requirement matching

              <span>02</span>
              BIS standards retrieval

              <span>03</span>
              Evidence-based AI explanation

              <span>04</span>
              Version & amendment verification

            </div>

          </section>

        </div>


        <aside className="analysis-side">

          <div className="side-card">

            <Sparkles size={25} />

            <h3>AI-Powered Analysis</h3>

            <p>
              The system uses semantic embeddings and a
              retrieval-augmented generation pipeline to find
              relevant BIS standards.
            </p>

          </div>


          <div className="side-card">

            <h3>Important</h3>

            <p>
              AI recommendations should be verified against
              official BIS records before procurement approval.
            </p>

          </div>

        </aside>

      </div>


      {requirement && (
        <RequirementCard requirement={requirement} />
      )}

    </div>
  );
}